/**
 * Cloud Function terjadwal — jalan otomatis SETIAP HARI (default jam 07:00 WIB),
 * mengecek semua tenggat kasus di Firestore, dan mengirim push notifikasi ke HP
 * tiap advokat yang menangani kasus itu (H-7 sampai H-0), berisi nama klien,
 * nomor perkara, dan H-berapa.
 *
 * CARA DEPLOY (lihat juga panduan yang dikirim terpisah):
 *   1. Install Firebase CLI: npm install -g firebase-tools
 *   2. firebase login
 *   3. Dari folder project ini: firebase init functions (pilih project trunojoyo-law-firm,
 *      pilih JavaScript, jangan overwrite file ini)
 *   4. Salin file ini ke functions/index.js (menimpa yang dibuat firebase init)
 *   5. cd functions && npm install firebase-admin firebase-functions
 *   6. Dari folder project: firebase deploy --only functions
 *
 * Firebase project HARUS di paket Blaze (bayar-sesuai-pakai) untuk pakai Cloud Functions —
 * tapi kuota gratis bulanan sangat besar, kantor kecil biasanya TIDAK akan kena biaya.
 */

const { onSchedule } = require("firebase-functions/v2/scheduler");
const admin = require("firebase-admin");
admin.initializeApp();

const db = admin.firestore();
const messaging = admin.messaging();

function daysUntil(dateStr) {
  const today = new Date(new Date().toISOString().slice(0, 10));
  const target = new Date(dateStr);
  return Math.ceil((target - today) / 86400000);
}

exports.dailyDeadlineNotifications = onSchedule(
  { schedule: "0 7 * * *", timeZone: "Asia/Jakarta" },
  async () => {
    // Data kasus & tenggat disimpan sebagai satu dokumen berisi array (lihat struktur useStore di app).
    const [casesSnap, deadlinesSnap, clientsSnap, tokensSnap] = await Promise.all([
      db.collection("trunojoyo_data").doc("cases").get(),
      db.collection("trunojoyo_data").doc("deadlines").get(),
      db.collection("trunojoyo_data").doc("clients").get(),
      db.collection("fcm_tokens").get(),
    ]);

    const cases = casesSnap.exists ? casesSnap.data().value || [] : [];
    const deadlines = deadlinesSnap.exists ? deadlinesSnap.data().value || [] : [];
    const clients = clientsSnap.exists ? clientsSnap.data().value || [] : [];

    const caseById = (id) => cases.find((c) => c.id === id) || {};
    const clientById = (id) => clients.find((c) => c.id === id) || {};

    // Kumpulkan token per nama advokat (satu advokat bisa punya beberapa perangkat)
    const tokensByAdvocate = {};
    tokensSnap.forEach((doc) => {
      const { advocateName } = doc.data();
      if (!advocateName) return;
      (tokensByAdvocate[advocateName] = tokensByAdvocate[advocateName] || []).push(doc.id);
    });

    const messages = [];
    deadlines.forEach((d) => {
      const dleft = daysUntil(d.dueDate);
      if (dleft < 0 || dleft > 7) return;
      const relCase = d.caseId ? caseById(d.caseId) : {};
      const relClient = relCase.clientId ? clientById(relCase.clientId) : {};
      const advocates = [relCase.advocateId, ...(relCase.coAdvocates || [])].filter(Boolean);
      const hLabel = dleft === 0 ? "Hari ini" : `H-${dleft}`;
      const title = `Tenggat ${hLabel}: ${d.title}`;
      const body = `${relClient.name ? relClient.name + " — " : ""}${relCase.caseNumber || "Umum"} — ${hLabel}`;

      advocates.forEach((adv) => {
        (tokensByAdvocate[adv] || []).forEach((token) => {
          messages.push({
            token,
            notification: { title, body },
            data: { deadlineId: String(d.id || "") },
            webpush: { fcmOptions: { link: "/" } },
          });
        });
      });
    });

    if (messages.length === 0) {
      console.log("Tidak ada tenggat H-7..H0 hari ini.");
      return;
    }

    const res = await messaging.sendEach(messages);
    console.log(`Terkirim: ${res.successCount}, gagal: ${res.failureCount}`);
  }
);
